from django.shortcuts import render, redirect
from .models import Order, Product
from decimal import Decimal

def index(request):
    context = {
        "all_products": Product.objects.all()
    }
    return render(request, "store/index.html", context)

def checkout(request):
    order = Order.objects.first()
    context = {
        'charge': order.charge,
        'quantity': order.quantity_ordered,
        'total': order.total_price
    }
    return render(request, "store/checkout.html", context)

def calculate(request):
    quantity_from_form = int(request.POST["quantity"])
    product_id = request.POST["product_id"]
    product = Product.objects.get(id=product_id)
    price_from_form = product.price
    total_charge = quantity_from_form * price_from_form
    print("Charging credit card...")
    order = Order.objects.first()
    order.charge = Decimal(total_charge)
    order.quantity_ordered += quantity_from_form
    order.total_price += Decimal(total_charge)
    order.save()
    return redirect('/checkout')

